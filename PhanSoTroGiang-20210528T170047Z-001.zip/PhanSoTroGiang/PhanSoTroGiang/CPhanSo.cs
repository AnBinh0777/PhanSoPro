﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PhanSoTroGiang
{
    class CPhanSo
    {
        int Tu1 = int.Parse(txtTu1.Text);
        int Mau1 = int.Parse(txtMau1.Text);
        int Tu2 = int.Parse(txtTu2.Text);
        int Mau2 = int.Parse(txtMau2.Text);
    }
}
